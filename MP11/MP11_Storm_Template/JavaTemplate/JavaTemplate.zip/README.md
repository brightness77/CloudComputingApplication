# Java Template for MP11 Storm

This is the Java template for ***"Machine Problem 11: Apache Storm / FLux"*** in 2022 Spring semester.
